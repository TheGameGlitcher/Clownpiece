## Character mod for the game Touhou Lost Branch of Legend

Credits:

ZUN in Team Shanghai Alice for creating Touhou Project.

Alioth Studio for making Lost Branch of Legends.

Programmer and Lead Designer:
- TheGameGlitcher

Card Designer for most "basic" cards:
- Elfonzo

Special Thanks:
- NeoShrimp for making the Sideloader and Watermark mods (Thanks shrimp)
- Lvalon, Cyaneko and Zosit for putting up with me learning how to mod the game as well as offering advice/interesting ideas
- Everyone else on the discord who were a part of the design process of this mod. There's too many names to remember, so don't feel left out!

Though this mod is unfinished, I will be publishing it and updating it for the purpose of playtesting. Please do not download this mod expecting complete polish.
