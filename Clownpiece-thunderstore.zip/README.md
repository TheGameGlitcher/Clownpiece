## Character mod for the game Touhou Lost Branch of Legend

Credits:

ZUN in Team Shanghai Alice for creating Touhou Project.

Alioth Studio for making Lost Branch of Legends.

Programmer and Lead Designer:
- TheGameGlitcher

Assistant Card Designer:
- Elfonzo

Special Thanks:
- NeoShrimp for making the Sideloader and Watermark mods (Thanks shrimp)
- Lvalon, Cyaneko and Zosit for putting up with me learning how to mod the game as well as offering advice/interesting ideas
- Intoxicated Kid for helping me make Shiki Eiki summon two enemies correctly
- Everyone else on the discord who were a part of the design process of this mod. There's too many names to remember, so don't feel left out!

As this is my first mod, please don't expect this to be vanilla tier quality. Though, I'm not scared of feedback. The more the merrier!
