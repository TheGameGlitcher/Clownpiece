## Character mod for the game Touhou Lost Branch of Legend

Credits:

ZUN in Team Shanghai Alice for creating Touhou Project.

Alioth Studio for making Lost Branch of Legends.

Programmer and Lead Designer:
- TheGameGlitcher

Assistant Card Designer:
- Elfonzo

Special Thanks:
- NeoShrimp for making the Sideloader and Watermark mods (Thanks shrimp)
- Lvalon, Cyaneko and Zosit for putting up with me learning how to mod the game as well as offering advice/interesting ideas
- Intoxicated Kid for helping me make Shiki Eiki summon two enemies correctly
- Everyone else on the discord who were a part of the design process of this mod. There's too many names to remember, so don't feel left out!

WARNING: This is my first mod and will be kept up for archival purposes. Although I welcome feedback, please do not expect this to be a very high quality mod. I'm doing my best.
