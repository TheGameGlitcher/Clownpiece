## Version 0.1.2
- Fixed poor wording on certain cards and effects
- Fixed Black Butterfly's Active Skill not targeting properly
- Fixed Racetrack applying it's temporary cost reduction to discarded cards instead of drawn cards

## Version 0.1.1
- Fixed an issue with certain statuses softlocking the game after a battle
- Fixed the version not updating properly
- (Actually remembered to use this changelog)

## Version 0.1.0
- Added Clownpiece