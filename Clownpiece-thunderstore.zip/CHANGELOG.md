## Version 0.1.1
- Fixed an issue with certain statuses softlocking the game after a battle
- Fixed the version not updating properly
- (Actually remembered to use this changelog)